//
//  InternApp.swift
//  Intern
//
//  Created by Zoltan Vinkler on 23/05/2023.
//

import SwiftUI

@main
struct InternApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
